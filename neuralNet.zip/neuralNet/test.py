def avg(x,y):
    print("THe first input is", x)
    print("second input is", y)
    a = (x + y) / 2.0
    print("average is", a)
    return a