
class Dog:
    
    #initialisation method with internal data
    def _init_(self, petname, temp):
        self.name = petname;
        self.temperature = temp;
    
    #get status
    def status(self):
        print("dog name is ", self.name)
        print("dog temperature is", self.tempreature)
        pass
    
    #set temperature
    def setTemperature(self, temp):
        self.temperature = temp;
        pass
        
    def bark(self):
        print("woof!")
        pass